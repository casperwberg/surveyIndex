deg2rad <-
function(deg) return(deg*pi/180)
